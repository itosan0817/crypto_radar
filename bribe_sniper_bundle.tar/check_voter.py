"""
Aerodrome Voter.isWhitelisted の動作確認スクリプト
（デバッグ用）
"""
import asyncio
from web3 import AsyncWeb3, AsyncHTTPProvider
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sniper.config import (
    ALCHEMY_BASE_HTTP_URL, AERODROME_VOTER_ADDRESS,
    VOTER_ABI, WHITELISTED_TOKENS
)

# Aerodrome 公式 Voter (v2) アドレス確認用の候補リスト
VOTER_CANDIDATES = [
    ("現在の設定", "0x16613524e02ad97eDfeF371bC883F2F5d6C480A5"),
    ("Aerodrome v2 Voter (公式ドキュメント)", "0x16613524e02ad97eDfeF371bC883F2F5d6C480A5"),
]

WHITELIST_ABI = [
    {
        "inputs": [{"internalType": "address", "name": "token", "type": "address"}],
        "name": "isWhitelisted",
        "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
        "stateMutability": "view",
        "type": "function"
    },
]

async def main():
    w3 = AsyncWeb3(AsyncHTTPProvider(ALCHEMY_BASE_HTTP_URL))
    print(f"接続状態: {await w3.is_connected()}")
    print(f"最新ブロック: {await w3.eth.block_number}")
    print()

    # 全ホワイトリストトークンで検証
    for label, voter_addr in VOTER_CANDIDATES:
        print(f"=== Voter: {label} ({voter_addr}) ===")
        voter = w3.eth.contract(
            address=w3.to_checksum_address(voter_addr),
            abi=WHITELIST_ABI
        )
        for symbol, token_addr in WHITELISTED_TOKENS.items():
            try:
                result = await voter.functions.isWhitelistedToken(
                    w3.to_checksum_address(token_addr)
                ).call()
                status = "✅ True" if result else "❌ False"
                print(f"  {status}  {symbol} ({token_addr})")
            except Exception as e:
                print(f"  ⚠️ ERROR  {symbol}: {e}")
        print()

if __name__ == "__main__":
    asyncio.run(main())
